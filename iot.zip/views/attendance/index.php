<div class="col-12">
    <div class="card">
        <div class="card-header">
            Class
            <button class="btn btn-primary float-end id-create-new mr-1" type="button">
                <i class="bi bi-share-fill"></i> Create
            </button>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-striped" id="tblLists" border="0">
                <thead>
                    <tr>
                        <th></th>
                        <th>Course</th>
                        <th>Staff</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th></th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>