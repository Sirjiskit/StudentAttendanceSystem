</div>
<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2021 &copy; IoT Attendance System</p>
        </div>
        <div class="float-end">
            <p>Powered by TSU Jalingo.</p>
        </div>
    </div>
</footer>
</div>

</div>
</div>

</body>