<form class="form form-vertical" id="form-upload-course" action="<?php echo URL; ?>courses/import">
    <div class="form-body">
        <div class="row">
            <div class="col-12">
                <div class="form-group">
                    <label for="paper">Excel File</label>
                    <input type="file" id="date"class="form-control" name="csv" required="" placeholder="Excel file">
                </div>
            </div>
            <div class="col-12" id="uploadReport">
                
            </div>
        </div>

    </div>
</form>